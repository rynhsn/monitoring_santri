<?= $this->extend('layouts/layout') ?>
<?= $this->section('content') ?>

<?= $this->endSection(); ?>